<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
get_header();
if ( have_posts() ) :
  while ( have_posts() ) : the_post();
    sanitize_title(the_content()); 
   endwhile;
else :
  esc_html_e ('<p>There are no content!</p>', 'codemaster');
endif;
get_footer();
?>