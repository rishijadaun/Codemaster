<?php 
/**
 * The template for displaying the footer.
 *
 * @package codemaster
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
</main>
<!-- **************** MAIN CONTENT END **************** -->
<!-- Footer -->
<footer role="contentinfo" class="text-center text-lg-start bg-light text-muted site-footer pt-3" itemscope="" itemtype="https://schema.org/WPFooter">
  <div class="footerblock1">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <?php if ( is_active_sidebar( 'sidebar-1' ) ) { ?>
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar-1' ); ?>
            </div>
        <?php } ?>
        </div>
        <!-- Grid column -->
        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
         <?php if ( is_active_sidebar( 'sidebar-2' ) ) { ?>
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar-2' ); ?>
            </div>
        <?php } ?>
        </div>
        <!-- Grid column -->
        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
         <?php if ( is_active_sidebar( 'sidebar-3' ) ) { ?>
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar-3' ); ?>
            </div>
        <?php } ?>
        </div>
        <!-- Grid column -->
        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <?php if ( is_active_sidebar( 'sidebar-4' ) ) { ?>
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar-4' ); ?>
            </div>
          <?php } ?>
         
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </div>
  <hr>
  <div class="footerblock2 bg-light">
   <!-- Copyright -->
   <div class="text-center p-4">
      <div class="site-info-copyright">
        &copy; <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php  bloginfo( 'name' ); ?></a>
       <a class="text-decoration-none" href="<?php echo esc_url( __( 'https://rankwebdevelopers.com/', 'codemaster' ) ); ?>">
        <?php
        _e( 'Codemaster Theme', 'codemaster' );
        ?>
      </a>
       </div><!-- .site-info -->
    </div>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
<a href="#" class="ct-scroll-top on"><i class="icofont-arrow-up"></i></a>
<?php wp_footer(); ?>
</body>
</html>