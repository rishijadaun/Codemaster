<?php
/**
 * The template for displaying the header.
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @package WordPress
 * @subpackage codemaster
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> itemtype="http://schema.org/WebSite" itemscope>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="profile" href="https://gmpg.org/xfn/11">
        <?php if(is_singular() && pings_open( get_queried_object() )): ?>
            <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
        <?php endif; ?>
        <meta name="theme-color" content="#7952b3">
        <?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>
        <?php wp_head(); ?>
    </head>
    <body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
        <header class="mainheader themeworkheader" role="banner" itemscope="" itemtype="https://schema.org/WPHeader">
            <a class="skip-link screen-reader-text" href="#main">
                <?php _e( 'Skip to content', 'codemaster' ); ?>
            </a>
    	   <nav class="navbar navbar-expand-lg navbar-light" role="navigation" itemscope="" itemtype="http://schema.org/SiteNavigationElement">
        	  <div class="container">
        	    <span class="navbar-brand site-branding" itemscope="itemscope" itemtype="https://schema.org/Organization" ><?php the_custom_logo(); ?></span>
        	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle navigation', 'codemaster' ) ?>">
        	      <span class="navbar-toggler-icon"></span>
        	    </button>
        	    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        	    	<?php if ( has_nav_menu( 'primary' ) ) { ?>
        				    <ul class="navbar-nav me-auto mb-lg-0 ms-auto primary-menu nav">
        							<?php
        								if ( has_nav_menu( 'primary' ) ) {
        									wp_nav_menu(
        										array(
        											'container'  => '',
        											'items_wrap' => '%3$s',
        											'theme_location' => 'primary',
        										)
        									);
        
        								}
        							?>
        				   </ul>
        			<?php } ?>
        	    </div>
        	  </div>
    	</nav>
    </header>
<main role="main" id="main">