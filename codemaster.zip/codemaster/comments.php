<?php 
/*
 * Check the current post is protected by a password
*/
if ( post_password_required() ) {
	return;
}
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} ?>
<div class="themework-comments">
    <?php wp_list_comments(); 
		paginate_comments_links( array(
		    'prev_text'  => '__( "Older Comments", "codemaster" )',
		    'next_text' => '__( "Newer Comments", "codemaster" )'
		) );
    ?>
</div>
