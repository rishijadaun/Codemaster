<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Template Name: Full Width 
 *
 */
get_header();
?>
<section class="page-content full-width">
	<div class="container-fluid">
<?php
       // Start the loop.
       while ( have_posts() ) : the_post();
          the_content();
       // End the loop.
       endwhile;
    ?>    
 </div> 
</section>
<?php 
get_footer(); 
?>
