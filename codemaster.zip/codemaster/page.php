<?php 
/**
 * The template for displaying the page.
 *
 * @package codemaster
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
get_header();
?>
<section class="pagecontent">
	<?php
	if ( have_posts() ) :
	  while ( have_posts() ) : the_post(); ?>
	  	<div class="ranking_page_banner">
	  	   <div class="container">
	        <h1 class="text-white display-5"><?php sanitize_title(the_title()) ?></h1>
	       </div>
	    </div>
	    <div class="container pb-5 pt-5">
	    <?php wp_strip_all_tags(the_content()) ?>
	   </div>
	  <?php endwhile;
	else :
	  esc_html_e ('<p>There are no posts!</p>', 'codemaster');
	endif;
	?> 
</section>
<?php get_footer(); ?>